package com.lesfurets.jenkins.unit.cps

import com.lesfurets.jenkins.unit.RegressionTest

abstract class BaseRegressionTestCPS extends BasePipelineTestCPS implements RegressionTest {

}
