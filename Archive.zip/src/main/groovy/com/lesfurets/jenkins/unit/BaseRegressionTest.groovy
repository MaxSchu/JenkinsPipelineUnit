package com.lesfurets.jenkins.unit

abstract class BaseRegressionTest extends BasePipelineTest implements RegressionTest {
}
